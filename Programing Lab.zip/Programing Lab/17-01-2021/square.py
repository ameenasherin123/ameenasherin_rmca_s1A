Python 3.9.1 (v3.9.1:1e5d33e9b9, Dec  7 2020, 12:10:52) 
[Clang 6.0 (clang-600.0.57)] on darwin
Type "help", "copyright", "credits" or "license()" for more information.
>>> digit = int(input("Enter an integer number: "))
Enter an integer number: 3
>>> square = digit*digit

>>> print(f"Square of {digit} is {square}")
Square of 3 is 9
>>> 
colors=(input('Enter colors separated by commas: ')).split(',')
print('First color:',colors[0])
print('Last color:',colors[len(colors)-1])

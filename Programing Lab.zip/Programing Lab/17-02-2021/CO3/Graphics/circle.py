def area(r):
    print('Area of circle with radius',r,'is:','%.2f'%(3.14*r*r),'Sq.units')
def circumference(r):
    print('Circumference of circle with radius',r,'is:','%.2f'%(3.14*2*r),'units')

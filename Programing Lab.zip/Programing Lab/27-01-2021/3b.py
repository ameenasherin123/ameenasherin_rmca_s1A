Python 3.9.1 (v3.9.1:1e5d33e9b9, Dec  7 2020, 12:10:52) 
[Clang 6.0 (clang-600.0.57)] on darwin
Type "help", "copyright", "credits" or "license()" for more information.
>>> list1 = [14,21,11,9,7,5]
>>> for n in list1:
    square = n**2
    print(n,'squared is',square)

14 squared is 196
21 squared is 441
11 squared is 121
9 squared is 81
7 squared is 49
5 squared is 25
>>> 

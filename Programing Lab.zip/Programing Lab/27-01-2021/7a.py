Python 3.9.1 (v3.9.1:1e5d33e9b9, Dec  7 2020, 12:10:52) 
[Clang 6.0 (clang-600.0.57)] on darwin
Type "help", "copyright", "credits" or "license()" for more information.
>>> list1 = [10, 10, 11, 12, 12, 13, 14, 16, 15, 16, 12]
>>> list2 = [16, 12, 13, 14, 15, 16, 10, 11, 12, 10, 12]
>>> len1=len(list1)
>>> len2=len(list2)
>>> if len1 == len2 :
	print('both list have equal length')
else:
	print('both list doesnt have equal length')

both list have equal length
>>> 
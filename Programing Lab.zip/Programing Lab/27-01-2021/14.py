Python 3.9.1 (v3.9.1:1e5d33e9b9, Dec  7 2020, 12:10:52) 
[Clang 6.0 (clang-600.0.57)] on darwin
Type "help", "copyright", "credits" or "license()" for more information.
>>> a = int(input("Input an integer : "))
Input an integer : 5
>>> n1=a
>>> n2=a*a
>>> n3=a*a*a
>>> print (n1+n2+n3)
155
>>> 

Python 3.9.1 (v3.9.1:1e5d33e9b9, Dec  7 2020, 12:10:52) 
[Clang 6.0 (clang-600.0.57)] on darwin
Type "help", "copyright", "credits" or "license()" for more information.
>>> a=['antony','ram','rohan','scaria']
>>> str1=(' '.join(a))
>>> count=0
>>> for i in str1: 
    if i == 'a': 
        count = count + 1

        
>>> print ("Count of a in the list is : "
                            +  str(count))

Count of a in the list is : 5
>>> 
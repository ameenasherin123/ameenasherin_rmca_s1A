Python 3.9.1 (v3.9.1:1e5d33e9b9, Dec  7 2020, 12:10:52) 
[Clang 6.0 (clang-600.0.57)] on darwin
Type "help", "copyright", "credits" or "license()" for more information.
>>> from math import pi
>>> r = float(input ("Input the radius of the circle : "))

Input the radius of the circle : 4
>>> print ("The area of the circle with radius " + str(r) + " is: " + str(pi * r**2))

The area of the circle with radius 4.0 is: 50.26548245743669
>>> 
numbers = [1,2,3,4,5,1,4,5] 
Sum = sum(numbers) 
print(Sum) 